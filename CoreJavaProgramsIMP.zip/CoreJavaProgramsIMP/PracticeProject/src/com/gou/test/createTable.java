package com.gou.test2;
import java.sql.*;
public class CreatTable {

	public static void main(String[] args)throws SQLException {
Driver d = new oracle.jdbc.driver.oracleDriver();
Drivermanager.registerDriver(d);
Connection con =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
Statement st =con.createStatment();
st.executeUpdate("creat table student(sno number(3),sname varchar2(10),smarks number(6,2))");
System.out.println("table is created");
	}

}
