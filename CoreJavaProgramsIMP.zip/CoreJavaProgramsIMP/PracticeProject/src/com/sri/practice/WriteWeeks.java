package com.sri.practice;
// Java program to demonstrate the example of 
// making write-only class in Java

public class WriteWeeks {
    // Private Data Member Declaration
    private String days;

    // Defining Setter method to write the value of
    // private properties and this method takes an argument 
    // and assign it in the private member.
    public void setDays(String days) {
        this.days = days;
    }

    // Defining Getter method to retrive the value of 
    //private variable

    public String getDays() {
        return days;
    }

    public static void main(String[] args) {
        // Weeks object instanstiation
        WriteWeeks w = new WriteWeeks();

        // Set the value of the private member
        w.setDays("7 Days");

        String result = w.getDays();
        // Display the value of the private properties
        System.out.println("Days in a Week :" + " " + result);

    }
}
