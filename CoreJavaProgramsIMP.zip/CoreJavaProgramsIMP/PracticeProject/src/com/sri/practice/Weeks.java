package com.sri.practice;
// Java program to demonstrate the example of 
 // making Read-only class in Java

 public class Weeks {
     // Private Data Member Declaration
     private String days = "7 days";

     // Defining Getter method to return the value of
     // private properties.
     public String getDays() {
         return days;
     }

     public static void main(String[] args) {
         // Weeks object instanstiation
         Weeks w = new Weeks();

         // Get the value of the private member
         String result = w.getDays();
         // Display the value of the private properties
         System.out.println("Days in a Week:" + " " + result);

     }
 }
