package com.seind.test;

public class Prime {

	public static void main(String[] args) {
		int count=0,n=91365;
		for(int i=1;i<=n;i++){
			if(n%i==0){
				count++;
			}
		}
			
			if(count==2){
				System.out.println("prime number");
			}
			else{
				System.out.println("not prime number");
			}
		

	}

}
