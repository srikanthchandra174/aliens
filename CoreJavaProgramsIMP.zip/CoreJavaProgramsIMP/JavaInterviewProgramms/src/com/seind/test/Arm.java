package com.seind.test;

public class Arm {

	public static void main(String[] args) {
		int n=153,sum=0,r,c;
		while(n>0) {
			r=n%10;
			c=r*r*r;
			sum=sum+c;
			n=n/10;
			
			}
		
			if(sum==n){
				System.out.println("armstrong number");
			}
			else{
				System.out.println("not armstron number");
			}
			
			
			
	}	
		
		// TODO Auto-generated method stub

	}


